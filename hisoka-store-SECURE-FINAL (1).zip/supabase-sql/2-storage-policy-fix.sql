-- Safe to run even if you already tried this once before

drop policy if exists "Public read listing images" on storage.objects;
drop policy if exists "Admin upload listing images" on storage.objects;
drop policy if exists "Admin delete listing images" on storage.objects;

create policy "Public read listing images" on storage.objects
  for select using (bucket_id = 'listing-images');

create policy "Admin upload listing images" on storage.objects
  for insert with check (bucket_id = 'listing-images' and auth.jwt() ->> 'email' = 'mhayiokikz@gmail.com');

create policy "Admin delete listing images" on storage.objects
  for delete using (bucket_id = 'listing-images' and auth.jwt() ->> 'email' = 'mhayiokikz@gmail.com');
