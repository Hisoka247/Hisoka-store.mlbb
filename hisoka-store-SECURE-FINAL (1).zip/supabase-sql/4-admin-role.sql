-- ============================================================
-- STEP 2 of 3 — Admin identity tied to your account's unique ID
-- (stronger than matching an email string)
-- Run AFTER supabase-security-hardening.sql.
-- ============================================================

create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);
alter table public.admins enable row level security;
-- (No policies on purpose: nobody can read or write this table through the API.)

insert into public.admins (user_id)
select id from auth.users where email = 'mhayiokikz@gmail.com'
on conflict do nothing;

-- One function every policy uses to ask "is this the admin?"
create or replace function public.is_admin()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to anon, authenticated;

-- ---------- listings ----------
drop policy if exists "Admin write listings"  on public.listings;
drop policy if exists "Admin insert listings" on public.listings;
drop policy if exists "Admin update listings" on public.listings;
drop policy if exists "Admin delete listings" on public.listings;
create policy "Admin insert listings" on public.listings for insert to authenticated with check (public.is_admin());
create policy "Admin update listings" on public.listings for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Admin delete listings" on public.listings for delete to authenticated using (public.is_admin());

-- ---------- categories ----------
drop policy if exists "Admin write categories"  on public.categories;
drop policy if exists "Admin insert categories" on public.categories;
drop policy if exists "Admin update categories" on public.categories;
drop policy if exists "Admin delete categories" on public.categories;
create policy "Admin insert categories" on public.categories for insert to authenticated with check (public.is_admin());
create policy "Admin update categories" on public.categories for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Admin delete categories" on public.categories for delete to authenticated using (public.is_admin());

-- ---------- sales log (private) ----------
drop policy if exists "Admin only sales_log" on public.sales_log;
drop policy if exists "Admin all sales_log"  on public.sales_log;
create policy "Admin all sales_log" on public.sales_log for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ---------- image storage ----------
drop policy if exists "Admin upload listing images" on storage.objects;
drop policy if exists "Admin delete listing images" on storage.objects;
create policy "Admin upload listing images" on storage.objects for insert to authenticated
  with check (bucket_id = 'listing-images' and public.is_admin());
create policy "Admin delete listing images" on storage.objects for delete to authenticated
  using (bucket_id = 'listing-images' and public.is_admin());
