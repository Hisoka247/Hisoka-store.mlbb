-- ============================================================
-- STEP 3 of 3 — Make the DATABASE itself demand two-factor
-- ONLY run this AFTER you have signed in to the admin panel,
-- set up your authenticator app, and confirmed you can get in.
-- If you run it before, you'll be locked out of editing
-- (customers would still see the store fine).
-- ============================================================

create or replace function public.is_admin()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (select 1 from public.admins where user_id = auth.uid())
     and coalesce(auth.jwt() ->> 'aal', '') = 'aal2';
$$;
-- Every policy already calls is_admin(), so this one change means:
-- a stolen password alone can no longer change a single thing.
