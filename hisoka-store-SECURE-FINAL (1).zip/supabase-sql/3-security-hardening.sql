-- ============================================
-- HISOKA STORE — DATABASE-LEVEL SECURITY HARDENING
-- Run this once in Supabase SQL Editor.
-- This adds constraints that hold even if the website's
-- own validation is ever bypassed entirely.
-- ============================================

-- Prevent negative or zero prices, and nonsense warranty values,
-- regardless of what the client sends.
alter table listings
  add constraint listings_price_positive check (price > 0),
  add constraint listings_price_usd_nonneg check (price_usd is null or price_usd >= 0),
  add constraint listings_warranty_valid check (
    warranty in ('7-day warranty', '14-day warranty', '30-day warranty')
  ),
  add constraint listings_title_not_empty check (length(trim(title)) > 0),
  add constraint listings_description_not_empty check (length(trim(description)) > 0);

-- Make sure a listing's category can only ever be one that actually
-- exists in your categories table — closes a gap where a listing could
-- reference a category name that was mistyped or already deleted.
alter table listings
  add constraint listings_category_fk
  foreign key (category) references categories(name)
  on update cascade on delete restrict;
-- "on delete restrict" means: Supabase will REFUSE to let you delete a
-- category while listings still use it — you'll need to reassign or
-- delete those listings first. This prevents silently orphaned listings.

-- Cap how long free-text fields can be, so nobody (accidentally or not)
-- can stuff megabytes of text into a single field.
alter table listings
  add constraint listings_title_length check (length(title) <= 200),
  add constraint listings_description_length check (length(description) <= 5000);

alter table categories
  add constraint categories_name_length check (length(name) <= 100 and length(trim(name)) > 0);

alter table sales_log
  add constraint sales_log_price_nonneg check (price is null or price >= 0);

-- Sanity check: image_url, if set, must actually look like a URL.
alter table listings
  add constraint listings_image_url_format check (
    image_url is null or image_url ~* '^https?://'
  );
