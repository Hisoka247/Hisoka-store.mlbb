# Hisoka Store — Security Hardening Guide

## 0. DO THIS FIRST: change your admin password
The old admin password was visible in the public source of the account page.
Treat it as compromised, even if you've since changed the site files.
Change it in Step 2 below (via "Forgot password?"), and never reuse it anywhere.

## Deploy order (follow exactly, or you can lock yourself out)

1. Upload ALL files in `site-files/` to your GitHub repo (index.html + 6 pages).
   Edit each existing file in place (pencil icon) — don't upload duplicates.
2. Open `/hisoka-store-admin.html` -> "Forgot password?" -> check email -> set a NEW password (12+ chars, letters+numbers).
3. Sign in. The first time, you'll be asked to SET UP TWO-FACTOR:
   scan the QR with Google Authenticator / Authy / 1Password, enter the 6-digit code.
   SAVE THE TEXT KEY shown under the QR in a password manager — it's your backup if you lose your phone.
4. Supabase -> SQL Editor: run these in order, one at a time:
   - `3-security-hardening.sql`   (data rules: price > 0, valid warranty, category must exist, etc.)
   - `4-admin-role.sql`           (admin identity tied to your unique account ID)
   - Confirm you can still add/edit a listing in admin.
   - `5-require-mfa-LAST.sql`     (database now REQUIRES two-factor for any change)
   If a script errors, copy the message to Claude — don't skip ahead.

## Supabase dashboard settings (only you can do these)
- Authentication -> Sign In / Providers -> turn OFF "Allow new users to sign up"
  (only one admin exists; customer accounts aren't built yet).
- Authentication -> Multi-Factor -> make sure TOTP is enabled.
- Authentication -> Sign In / Providers -> Password policy: minimum length 12+.
- Authentication -> Attack Protection: enable CAPTCHA if available; review Rate Limits.
- Your Supabase ACCOUNT (top-right avatar -> Account): turn on two-factor there too.
  Whoever controls that account controls everything.
- GitHub account: turn on two-factor there too (it controls your site's code).
- BigRock/domain account: turn on two-factor and keep auto-renew ON.
- Database -> Backups: check what your plan includes. Free plans have no scheduled backups.
  Export your tables (Table Editor -> Export CSV) now and then.

## What is now protected
- Only YOU can add/edit/delete; enforced by the database, not the page.
- Password alone isn't enough (authenticator code required) — and after step 4-5 the database enforces it.
- Identity is verified server-side on every load; local storage can't fake an admin session.
- Auto sign-out after 30 minutes idle; "Sign out" ends all sessions.
- All listing text is escaped before display (stored-XSS closed).
- Image uploads: type + size checked, random filenames.
- Data rules enforced by the database itself.
- Content-Security-Policy restricts where scripts/data can go.
- Password reset never reveals whether an email exists.

## Honest limits (nothing is "hacker-proof")
- GitHub Pages can't send security headers (X-Frame-Options, HSTS...), so clickjacking
  protection isn't possible on this host. Cloudflare (free) in front of the domain would add it.
- The CSP still allows inline scripts (the pages use them), so it limits damage but isn't a full XSS wall.
- The supabase-js library loads from a CDN without a pinned version/integrity hash.
  Pinning it needs an exact version + hash checked on jsdelivr.com — do that when convenient.
- Customer sign-in (Google/email) is still a DEMO with no real accounts. It stores nothing real,
  but consider hiding the "Sign in" link until it's built properly.
- Losing your phone AND the saved key means recovering via the Supabase dashboard
  (Authentication -> Users -> your user -> remove the factor). Keep that key safe.
- No automatic monitoring/alerts. Glance at admin regularly for changes you didn't make.
